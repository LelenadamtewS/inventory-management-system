SERVICE_URLS = {
    "inventory": "http://inventory:8001",  # URL for the inventory service
    "order": "http://order:8002",          # URL for the order service
}
