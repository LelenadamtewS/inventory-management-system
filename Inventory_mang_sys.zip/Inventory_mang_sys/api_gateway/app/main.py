from fastapi import FastAPI, HTTPException, Request
from httpx import AsyncClient
from app.config import SERVICE_URLS

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "API Gateway is running"}

@app.api_route("/{service}/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def proxy(service: str, path: str, request: Request):
    if service not in SERVICE_URLS:
        raise HTTPException(status_code=404, detail="Service not found")

    # Forward request to appropriate service
    service_url = SERVICE_URLS[service]
    async with AsyncClient() as client:
        response = await client.request(
            method=request.method,
            url=f"{service_url}/{path}",
            headers=request.headers,
            json=await request.json() if request.method in ["POST", "PUT"] else None,
        )
        return response.json()
