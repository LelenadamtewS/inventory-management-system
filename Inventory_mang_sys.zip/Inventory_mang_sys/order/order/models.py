# order/models.py

from django.db import models

class Order(models.Model):
    order_id = models.AutoField(primary_key=True)
    product_id = models.IntegerField()  # Store the product ID as an integer
    quantity = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
