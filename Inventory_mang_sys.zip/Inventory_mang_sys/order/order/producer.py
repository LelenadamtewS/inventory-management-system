import pika
import json

def publish_message(queue, message):
    # Connect to RabbitMQ
    connection = pika.BlockingConnection(pika.ConnectionParameters('api_gateway-rabbitmq'))

    channel = connection.channel()
    # Declare the queue
    channel.queue_declare(queue=queue)
    # Publish the message
    channel.basic_publish(exchange='', routing_key=queue, body=json.dumps(message))
    print(f"Sent message to {queue}: {message}")
    # Close the connection
    connection.close()

# Simulating sending an order
order_data = {
    "order_id": 12345,
    "items": [
        {"product_id": 1, "quantity": 10},
        {"product_id": 2, "quantity": 5}
    ]
}

publish_message("order_queue", order_data)
