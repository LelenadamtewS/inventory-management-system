from django.http import JsonResponse
from .producer import publish_message

def create_order(request):
    # Simulate order creation
    order_data = {
        'order_id': 123,
        'items': [
            {'product_id': 1, 'quantity': 2},
            {'product_id': 2, 'quantity': 1}
        ]
    }
    # Send the order data to RabbitMQ
    publish_message('inventory_queue', order_data)
    return JsonResponse({'message': 'Order created and sent to inventory!', 'order': order_data})
