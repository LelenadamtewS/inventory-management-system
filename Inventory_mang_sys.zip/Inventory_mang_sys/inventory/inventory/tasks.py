from celery import shared_task
import pika

@shared_task
def send_message_to_queue(message):
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='rabbitmq'))
    channel = connection.channel()

    # Declare the queue
    channel.queue_declare(queue='your_queue_name')

    # Publish the message
    channel.basic_publish(exchange='',
                          routing_key='your_queue_name',
                          body=message)
    connection.close()
    print(f"Message '{message}' sent to the queue.")
