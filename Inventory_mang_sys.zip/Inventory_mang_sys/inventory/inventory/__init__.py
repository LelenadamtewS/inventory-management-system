from .consumer import start_consumer

# Start the consumer when the service is initialized
start_consumer('inventory_queue')
