import pika
import json

def process_order(data):
    # Simulate inventory update based on the order data
    print(f"Processing order: {data}")
    for item in data['items']:
        print(f"Updating inventory for product {item['product_id']} - Quantity: {item['quantity']}")

def callback(ch, method, properties, body):
    # Callback function to handle incoming messages
    data = json.loads(body)
    print(f"Received message: {data}")
    process_order(data)

def start_consumer(queue):
    # Connect to RabbitMQ
    connection = pika.BlockingConnection(pika.ConnectionParameters('rabbitmq'))
    channel = connection.channel()
    # Declare the queue
    channel.queue_declare(queue=queue)
    # Start consuming messages
    channel.basic_consume(queue=queue, on_message_callback=callback, auto_ack=True)
    print(f"Listening on queue: {queue}")
    channel.start_consuming()

# Call the start_consumer function with the queue name to start listening for messages
if __name__ == "__main__":
    start_consumer('order_queue')
