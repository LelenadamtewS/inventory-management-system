# inventory/urls.py
from django.urls import path
from .views import ProductView, UpdateStockView

urlpatterns = [
    path('check_stock/<int:product_id>/', ProductView.as_view(), name='check_stock'),
    path('update_stock/<int:product_id>/', UpdateStockView.as_view(), name='update_stock'),
]
