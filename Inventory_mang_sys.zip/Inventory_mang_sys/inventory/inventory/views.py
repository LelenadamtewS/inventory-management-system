from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse

# In-memory storage for inventory data (Simulating a simple database)
inventory_db = {
    1: {"product_id": 1, "name": "Product A", "quantity": 100},
    2: {"product_id": 2, "name": "Product B", "quantity": 50},
    3: {"product_id": 3, "name": "Product C", "quantity": 200},
}

class ProductView(APIView):
    """
    View to get product details from the inventory.
    """
    def get(self, request, product_id):
        # Check if product exists in inventory
        product = inventory_db.get(product_id)
        if not product:
            return JsonResponse({"error": "Product not found"}, status=status.HTTP_404_NOT_FOUND)
        
        return Response(product, status=status.HTTP_200_OK)

class UpdateStockView(APIView):
    """
    View to update product stock in the inventory.
    """
    def post(self, request, product_id):
        # Get the product from the database
        product = inventory_db.get(product_id)
        if not product:
            return JsonResponse({"error": "Product not found"}, status=status.HTTP_404_NOT_FOUND)

        # Check if quantity update is valid
        data = request.data
        quantity_to_update = data.get('quantity')
        
        if quantity_to_update is None:
            return JsonResponse({"error": "Quantity is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        # Update stock (decrease if negative value, increase if positive value)
        new_quantity = product["quantity"] + quantity_to_update
        
        if new_quantity < 0:
            return JsonResponse({"error": "Insufficient stock"}, status=status.HTTP_400_BAD_REQUEST)

        # Update the product's stock
        product["quantity"] = new_quantity
        return JsonResponse({"message": f"Stock updated for product {product_id}. New quantity: {new_quantity}"}, status=status.HTTP_200_OK)
