# inventory/tests/test_api.py
from rest_framework.test import APITestCase
from rest_framework import status
from inventory.models import Item  # Replace with your actual model
from django.urls import reverse

class ItemApiTests(APITestCase):

    def setUp(self):
        """Create initial test data before each test."""
        self.item = Item.objects.create(name="Test Item", price=100)
        self.url = reverse('item-list')  # Change 'item-list' to your actual URL name

    def test_item_list(self):
        """Test retrieving the list of items."""
        response = self.client.get(self.url)

        # Check that the status code is 200 (OK)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Check that the item we created is in the response data
        self.assertEqual(response.data[0]['name'], "Test Item")

    def test_create_item(self):
        """Test creating a new item."""
        data = {
            'name': 'New Item',
            'price': 150
        }
        response = self.client.post(self.url, data, format='json')

        # Check if the status code is 201 (Created)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # Verify that the item was added to the database
        self.assertEqual(Item.objects.count(), 2)  # One created in setUp, one created via POST

    def test_update_item(self):
        """Test updating an existing item."""
        # Update the item with a PUT request
        data = {
            'name': 'Updated Item',
            'price': 200
        }
        update_url = reverse('item-detail', kwargs={'pk': self.item.pk})  # Change to your actual URL pattern
        response = self.client.put(update_url, data, format='json')

        # Check if the status code is 200 (OK)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Check that the item is updated in the database
        self.item.refresh_from_db()
        self.assertEqual(self.item.name, 'Updated Item')
        self.assertEqual(self.item.price, 200)

    def test_delete_item(self):
        """Test deleting an item."""
        delete_url = reverse('item-detail', kwargs={'pk': self.item.pk})  # Change to your actual URL pattern
        response = self.client.delete(delete_url)

        # Check if the status code is 204 (No Content)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

        # Verify that the item is deleted from the database
        self.assertEqual(Item.objects.count(), 0)  # Only the test item was created
